Created by Robert Jones
12-12-2017
as a final assignment for Computer Science 2 at Landmark College

This java program will let you play against a simple AI.
Over time this IA will learn optimal stratigie based on past games.
It does this by adjusting the probability of plays based on the degree of success.
By telling it to use a custom AI folder it will refear to a unique history/probability.

GUI and automated learning coming soon!